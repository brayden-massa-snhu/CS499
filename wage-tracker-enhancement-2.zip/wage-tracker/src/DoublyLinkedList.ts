import { Shift } from './types/ShiftType'

class Node<T> {
  public data: T
  public next: Node<T> | null = null
  public prev: Node<T> | null = null

  constructor(data: T) {
    this.data = data
  }
}

export class DoublyLinkedList<T> {
  public head: Node<T> | null = null
  public tail: Node<T> | null = null
  private length: number = 0

  // Append a new node with data of type T
  append(data: T): void {
    const newNode = new Node(data)
    if (!this.head) {
      this.head = newNode
      this.tail = newNode
    } else if (this.tail) {
      this.tail.next = newNode
      newNode.prev = this.tail
      this.tail = newNode
    }
    this.length++
  }

  // Delete a node by providing a comparison function
  delete(compareFn: (data: T) => boolean): void {
    let current = this.head
    while (current) {
      if (compareFn(current.data)) {
        if (current.prev) {
          current.prev.next = current.next
        } else {
          this.head = current.next // Deleting the head node
        }
        if (current.next) {
          current.next.prev = current.prev
        } else {
          this.tail = current.prev // Deleting the tail node
        }
        this.length--
        return
      }
      current = current.next
    }
  }

  // Convert the linked list to an array
  toArray(): T[] {
    const result: T[] = []
    let current = this.head
    while (current) {
      result.push(current.data)
      current = current.next
    }
    return result
  }

  // Get the length of the list
  getLength(): number {
    return this.length
  }

  // Defines a method to sort the linked list using the insertion sort algorithm
  insertionSort(comparator: (a: T, b: T) => number) {
    if (!this.head || !this.head.next) return

    let sorted: DoublyLinkedList<T> = new DoublyLinkedList<T>()
    let currentNode: Node<T> | null = this.head

    while (currentNode) {
      let nextNode: Node<T> | null = currentNode.next
      this.insertInOrder(sorted, currentNode, comparator)
      currentNode = nextNode
    }
    this.head = sorted.head
    this.tail = sorted.tail
    this.length = sorted.length
  }
  insertInOrder(
    sortedList: DoublyLinkedList<T>,
    newNode: Node<T>,
    comparator: (a: T, b: T) => number
  ) {
    if (
      !sortedList.head ||
      comparator(newNode.data, sortedList.head.data) < 0
    ) {
      // Insert at the beginning
      newNode.next = sortedList.head
      if (sortedList.head) {
        sortedList.head.prev = newNode
      }
      sortedList.head = newNode
      sortedList.tail = sortedList.tail || newNode
    } else {
      let current = sortedList.head
      while (current.next && comparator(newNode.data, current.next.data) > 0) {
        current = current.next
      }
      newNode.next = current.next
      if (current.next) {
        current.next.prev = newNode
      }
      current.next = newNode
      newNode.prev = current
      sortedList.tail = newNode
    }
    sortedList.length++
  }
}
