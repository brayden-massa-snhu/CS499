import { Shift } from '../types/ShiftType'
import WageCalculator from '../WageCalculator'

type Props = {
  shift: Shift
  onDelete: (id: number) => void
}

/**
 * Component to display a shift on the ViewShifts page.
 * Each shift will have its own ShiftView
 *
 * @param shift Shift to be displayed
 * @param onDelete Called when a shift is to be deleted
 * @returns
 */
const ShiftView = ({ shift, onDelete }: Props) => {
  //Initialize Wage Calculator
  const wageCalc = new WageCalculator(shift)

  return (
    <li key={shift.id} id='shift-view'>
      {shift.shiftType} shift for {shift.hoursWorked.toFixed(1)} hours | Card
      tips: ${shift.totalCardTips} | Cash tips: ${shift.totalCashTips} | $/hr: $
      {wageCalc.totalMoneyPerHour().toFixed(2)} | total $: $
      {wageCalc.totalMoney().toFixed(2)}{' '}
      <button className='shift-view-delete' onClick={() => onDelete(shift.id)}>
        Delete
      </button>
    </li>
  )
}

export default ShiftView
