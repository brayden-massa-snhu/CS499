import { Shift } from './types/ShiftType'

/**
 * Calculator for calculating statistics for a single shift
 */
export default class WageCalculator {
  readonly hoursWorked: number
  readonly cashTips: number
  readonly cardTips: number
  readonly hourlyWage: number

  constructor(shift: Shift) {
    this.hoursWorked = shift.hoursWorked
    this.cashTips = shift.totalCashTips
    this.cardTips = shift.totalCardTips
    this.hourlyWage = 6.75
  }

  //Returns total card and cash tips for selected shift
  totalTips(): number {
    return this.cashTips + this.cardTips
  }

  //Returns money made from just hourly wage for selected shift
  totalHourly(): number {
    return this.hourlyWage * this.hoursWorked
  }

  //Returns total money made (tips and wage) for selected shift
  totalMoney(): number {
    return this.totalHourly() + this.totalTips()
  }

  //Returns average dollars per hour (tips and wage) for selected shift
  totalMoneyPerHour(): number {
    if (this.hoursWorked === 0) return 0
    return this.totalMoney() / this.hoursWorked
  }
}
