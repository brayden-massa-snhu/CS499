import { DoublyLinkedList } from './DoublyLinkedList'
import { Shift } from './types/ShiftType'
import WageCalculator from './WageCalculator'
export default class StatisticsCalculator {
  shifts: DoublyLinkedList<Shift>
  constructor(shifts: DoublyLinkedList<Shift>) {
    this.shifts = shifts
  }

  private checkForShifts() {
    return this.shifts && this.shifts.getLength() > 0
  }
  totalHourlyRate() {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalHours = 0
    let totalMoney = 0
    let currentNode = this.shifts.head
    while (currentNode) {
      const shift = currentNode.data
      const wageCalc = new WageCalculator(shift)
      totalHours += shift.hoursWorked
      totalMoney += wageCalc.totalMoney()
      currentNode = currentNode.next
    }
    if (totalHours === 0) return 0
    return totalMoney / totalHours
  }

  totalMoney() {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalMoney = 0
    let currentNode = this.shifts.head
    while (currentNode) {
      const wageCalc = new WageCalculator(currentNode.data)
      totalMoney += wageCalc.totalMoney()
      currentNode = currentNode.next
    }
    return totalMoney
  }

  totalHours() {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalHours = 0
    let currentNode = this.shifts.head
    while (currentNode) {
      totalHours += currentNode.data.hoursWorked
      currentNode = currentNode.next
    }
    return totalHours
  }
  private totalHourlyRateBasedOnShiftType(shiftType: string) {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalHours = 0
    let totalMoney = 0
    let currentNode = this.shifts.head
    while (currentNode) {
      const shift = currentNode.data
      if (shift.shiftType === shiftType) {
        const wageCalc = new WageCalculator(shift)
        totalHours += shift.hoursWorked
        totalMoney += wageCalc.totalMoney()
      }
      currentNode = currentNode.next
    }
    if (totalHours === 0) return 0
    return totalMoney / totalHours
  }
  totalHourlyRateServing() {
    return this.totalHourlyRateBasedOnShiftType('Server')
  }
  totalHourlyRateBartending() {
    return this.totalHourlyRateBasedOnShiftType('Bartender')
  }
}
