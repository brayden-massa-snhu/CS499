export type Shift = {
  shiftType: string
  hoursWorked: number
  totalCardTips: number
  totalCashTips: number
  id: number
  date: Date
}
