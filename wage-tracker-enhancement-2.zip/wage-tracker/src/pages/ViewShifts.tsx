//import { useState, useEffect } from 'react'
import { Shift } from '../types/ShiftType'
import ShiftView from '../components/ShiftView'
import BackArrow from '../components/BackArrow'
import '../styles/ViewShifts.css'
import { useShifts } from '../hooks/useShifts'

const ViewShifts = () => {
  const { shifts, deleteShift } = useShifts()

  const handleDeleteShift = (id: number) => {
    deleteShift(id)
  }
  const renderShifts = () => {
    let currentNode = shifts.head
    const shiftElements = []

    // Traverse through the linked list and push JSX into shiftElements array
    while (currentNode !== null) {
      const shift = currentNode.data
      shiftElements.push(
        <ShiftView key={shift.id} shift={shift} onDelete={handleDeleteShift} />
      )
      currentNode = currentNode.next // Move to the next node in the list
    }

    // Reverse the order since you want to display shifts in reverse order
    return shiftElements.reverse()
  }

  return (
    <div id='view-shifts-container'>
      <BackArrow id='view-back-arrow' />
      {shifts.getLength() === 0 ? (
        <h1 id='no-shifts'>There are no shifts.</h1>
      ) : (
        shifts.getLength() > 0 && (
          <>
            <h1 className='heading' id='view-shifts-heading'>
              Shifts
            </h1>
            <div id='view-shifts-sort-container'>
              <h1>Sort by: </h1>
              <label htmlFor='sort-by-hours'>Hours</label>
            </div>
            <ul id='view-shifts-list'>{renderShifts()}</ul>
          </>
        )
      )}
    </div>
  )
}
export default ViewShifts
