import { useState, useEffect } from 'react'
import ShiftView from '../components/ShiftView'
import BackArrow from '../components/BackArrow'
import '../styles/ViewShifts.css'
import { useShifts } from '../hooks/useShifts'
import { Shift } from '../types/ShiftType'
import WageCalculator from '../WageCalculator'

/**
 * Page to display shifts and data from shifts
 *
 * @returns JSX for the ViewShifts page
 */
const ViewShifts = () => {
  //Gets the shifts list from global state
  const { shifts, deleteShift } = useShifts()
  //State for the sorting option
  const [sortOption, setSortOption] = useState<string>('Date')

  // Function to handle the sorting based on the selected option
  const handleSort = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedOption = e.target.value
    setSortOption(selectedOption)
    sortShifts(selectedOption)
  }

  // Function to sort the shifts based on the selected option
  const sortShifts = (option: string) => {
    const comparator = (a: Shift, b: Shift) => {
      switch (option) {
        case 'Hours':
          return b.hoursWorked - a.hoursWorked
        case 'Card tips':
          return b.totalCardTips - a.totalCardTips
        case 'Cash tips':
          return b.totalCashTips - a.totalCashTips
        case 'Total money':
          const wageCalcA = new WageCalculator(a)
          const wageCalcB = new WageCalculator(b)
          return wageCalcB.totalMoney() - wageCalcA.totalMoney()
        case 'Date':
        default:
          return new Date(b.date).getTime() - new Date(a.date).getTime()
      }
    }
    shifts.insertionSort(comparator)
  }

  //Called to delete a shift from the list
  const handleDeleteShift = (id: number) => {
    deleteShift(id)
  }
  //Renders the list of shifts to JSX
  const renderShifts = () => {
    let currentNode = shifts.head
    const shiftElements = []

    // Traverse through the linked list and push JSX into shiftElements array
    while (currentNode !== null) {
      const shift = currentNode.data
      shiftElements.push(
        <ShiftView key={shift.id} shift={shift} onDelete={handleDeleteShift} />
      )
      currentNode = currentNode.next // Move to the next node in the list
    }

    return shiftElements
  }
  //Sort the shifts by date when page is first rendered
  useEffect(() => {
    sortShifts('Date')
  }, [])

  return (
    <div id='view-shifts-container'>
      <BackArrow id='view-back-arrow' />
      {shifts.getLength() === 0 ? (
        <h1 id='no-shifts'>There are no shifts.</h1>
      ) : (
        shifts.getLength() > 0 && (
          <>
            <h1 className='heading' id='view-shifts-heading'>
              Shifts
            </h1>
            <div id='view-shifts-sort-container'>
              <h1>Sort by: </h1>
              <select
                name='sort-shifts-select'
                id='sort-shifts-select'
                onChange={handleSort}
                value={sortOption}
              >
                <option value='Date'>Date (default)</option>
                <option value='Hours'>Hours Worked</option>
                <option value='Card tips'>Card Tips</option>
                <option value='Cash tips'>Cash Tips</option>
                <option value='Total money'>Total Money</option>
              </select>
            </div>
            <ul id='view-shifts-list'>{renderShifts()}</ul>
          </>
        )
      )}
    </div>
  )
}
export default ViewShifts
