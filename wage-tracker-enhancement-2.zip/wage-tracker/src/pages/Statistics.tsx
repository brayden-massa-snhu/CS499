import StatisticsCalculator from '../StatisticsCalculator'
import { useState, useEffect } from 'react'
import BackArrow from '../components/BackArrow'
import '../styles/Statistics.css'
import { useShifts } from '../hooks/useShifts'

/**
 * Displays statistics about the list of shifts in the application
 *
 * @returns JSX for the Statistics page
 */
const Statistics = () => {
  //Sets up the statistics calculator
  const [statsCalc, setStatsCalc] = useState<StatisticsCalculator | null>(null)
  //Retrievs shifts list from global state
  const { shifts } = useShifts()

  //Initialize the statistics calculator, which changes whenever the shifts list changes
  useEffect(() => {
    const initializeStatsCalc = () => {
      const calc = new StatisticsCalculator(shifts)
      setStatsCalc(calc)
    }
    initializeStatsCalc()
  }, [shifts])

  return (
    <div className='container'>
      <h1 className='heading' id='statistics-heading'>
        Statistics
      </h1>
      <main id='stats-main' className='main'>
        <BackArrow id='stats-back-arrow' />
        <p>Total hours worked: {statsCalc?.totalHours().toFixed(1)}</p>
        <p>Total money: ${statsCalc?.totalMoney().toFixed(2)}</p>
        <p>
          Total average hourly rate: ${statsCalc?.totalHourlyRate().toFixed(2)}
        </p>
        <p>
          Total Serving hourly rate: $
          {statsCalc?.totalHourlyRateServing().toFixed(2)}
        </p>
        <p>
          Total Bartending hourly rate: $
          {statsCalc?.totalHourlyRateBartending().toFixed(2)}
        </p>
      </main>
    </div>
  )
}
export default Statistics
