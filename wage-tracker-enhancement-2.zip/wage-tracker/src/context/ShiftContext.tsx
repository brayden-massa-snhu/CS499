import { createContext, useState, ReactNode } from 'react'
import { Shift } from '../types/ShiftType'
import { DoublyLinkedList } from '../DoublyLinkedList'

/**
 * Uses react context to store global state information for the shifts,
 * as well as methods to remove shifts and append new shifts
 */

interface ShiftContextType {
  shifts: DoublyLinkedList<Shift>
  appendShift: (shift: Shift) => void
  deleteShift: (id: number) => void
}

export const ShiftContext = createContext<ShiftContextType | undefined>(
  undefined
)

export const ShiftProvider = ({ children }: { children: ReactNode }) => {
  //State for shifts is initialized here
  const [shiftList] = useState(new DoublyLinkedList<Shift>())
  const [nextID, setNextID] = useState(1)

  const appendShift = (shift: Shift) => {
    shift.id = nextID
    shiftList.append(shift)
    setNextID(nextID + 1)
  }

  const deleteShift = (id: number) => {
    shiftList.delete((shift: Shift) => shift.id === id)
  }
  return (
    <ShiftContext.Provider
      value={{ shifts: shiftList, appendShift, deleteShift }}
    >
      {children}
    </ShiftContext.Provider>
  )
}
