import { useContext } from 'react'
import { ShiftContext } from '../context/ShiftContext'

//Custom hook to make using global state more simple
export const useShifts = () => {
  const context = useContext(ShiftContext)
  if (!context) {
    throw new Error('useShifts must be used within a ShiftProvider')
  }
  return context
}
