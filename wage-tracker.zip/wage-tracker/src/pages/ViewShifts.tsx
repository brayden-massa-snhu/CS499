import { useState, useEffect } from 'react'
import { Shift } from '../types/ShiftType'
import ShiftView from '../components/ShiftView'
import BackArrow from '../components/BackArrow'
import '../styles/ViewShifts.css'
import { useShifts } from '../hooks/useShifts'

const ViewShifts = () => {
  const { shifts, setShifts } = useShifts()

  const handleDeleteShift = (id: number) => {
    setShifts(shifts.filter((shift) => shift.id != id))
  }

  const reversedShifts = [...shifts].reverse()
  return (
    <div id='view-shifts-container'>
      <BackArrow id='view-back-arrow' />
      {shifts.length === 0 && <h1 id='no-shifts'>There are no shifts.</h1>}
      {shifts.length > 0 && (
        <>
          <h1 className='heading' id='view-shifts-heading'>
            Shifts
          </h1>
          <ul id='view-shifts-list'>
            {reversedShifts.map((shift: Shift) => (
              <ShiftView shift={shift} onDelete={handleDeleteShift} />
            ))}
          </ul>
        </>
      )}
    </div>
  )
}
export default ViewShifts
