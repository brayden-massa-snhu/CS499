import { Shift } from '../types/ShiftType'
import WageCalculator from '../WageCalculator'

type Props = {
  shift: Shift
  onDelete: (id: number) => void
}

const ShiftView = ({ shift, onDelete }: Props) => {
  const calc = new WageCalculator(shift)

  return (
    <li key={shift.id} id='shift-view'>
      {shift.shiftType} shift for {shift.hoursWorked.toFixed(1)} hours | Card
      tips: ${shift.totalCardTips} | Cash tips: ${shift.totalCashTips} | $/hr: $
      {calc.totalMoneyPerHour().toFixed(2)} | total $: $
      {calc.totalMoney().toFixed(2)}{' '}
      <button className='shift-view-delete' onClick={() => onDelete(shift.id)}>
        Delete
      </button>
    </li>
  )
}

export default ShiftView
