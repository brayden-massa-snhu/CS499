import { createContext, useState, ReactNode } from 'react'
import { Shift } from '../types/ShiftType'

interface ShiftContextType {
  shifts: Shift[]
  setShifts: React.Dispatch<React.SetStateAction<Shift[]>>
}

export const ShiftContext = createContext<ShiftContextType | undefined>(
  undefined
)

export const ShiftProvider = ({ children }: { children: ReactNode }) => {
  const [shifts, setShifts] = useState<Shift[]>([])
  return (
    <ShiftContext.Provider value={{ shifts, setShifts }}>
      {children}
    </ShiftContext.Provider>
  )
}
