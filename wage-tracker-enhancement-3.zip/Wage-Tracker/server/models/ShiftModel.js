const mongoose = require('mongoose')

/**
 * Mongoose schema for Shifts table
 * Defines the fields for the Shift in the database
 */
const shiftSchema = new mongoose.Schema({
  shiftType: {
    type: String,
    required: true,
  },
  hoursWorked: {
    type: Number,
    required: true,
  },
  totalCardTips: {
    type: Number,
    required: true,
  },
  totalCashTips: {
    type: Number,
    required: true,
  },
  date: {
    type: Date,
    default: Date.now(),
  },
})
// Export to the "Shifts" table
module.exports = mongoose.model('Shifts', shiftSchema)
