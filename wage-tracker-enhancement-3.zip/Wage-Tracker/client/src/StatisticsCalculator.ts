import axios from 'axios'
import { Shift } from './types/ShiftType'
import WageCalculator from './WageCalculator'

/**
 * Calculator to calculate information across all shifts (averages, totals, etc.)
 */
export default class StatisticsCalculator {
  shifts: Shift[] | null
  constructor() {
    this.shifts = null
  }
  // Calls fetchShifts which assigns this.shifts
  async init() {
    await this.fetchShifts()
  }
  // Helper to retrieve the shifts from the database
  private async fetchShifts() {
    try {
      const res = await axios.get('http://localhost:4000/shifts')
      this.shifts = res.data
    } catch (err) {
      console.error('Error fetching shifts: ', err)
    }
  }
  // Ensures shifts list is not empty
  private checkForShifts() {
    if (!this.shifts || this.shifts.length === 0) {
      return false
    }
    return true
  }

  // Returns total average hourly rate (wage and tips) for all shifts
  totalHourlyRate() {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalHours = 0
    let totalMoney = 0
    for (let i = 0; i < this.shifts!.length; i++) {
      const shift = this.shifts![i]
      const wageCalc = new WageCalculator(shift)
      totalHours += shift.hoursWorked
      totalMoney += wageCalc.totalMoney()
    }
    if (totalHours === 0) return 0
    return totalMoney / totalHours
  }

  // Returns total sum of money for all shifts (wage and tips)
  totalMoney() {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalMoney = 0
    for (let i = 0; i < this.shifts!.length; i++) {
      const wageCalc = new WageCalculator(this.shifts![i])
      totalMoney += wageCalc.totalMoney()
    }
    return totalMoney
  }

  // Returns total sum of hours across all shifts
  totalHours() {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalHours = 0
    for (let i = 0; i < this.shifts!.length; i++) {
      totalHours += this.shifts![i].hoursWorked
    }
    return totalHours
  }

  // Helper method to calculate average hourly rate (tips and wage) for shifts
  // of selected ShiftType
  private totalHourlyRateBasedOnShiftType(shiftType: string) {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalHours = 0
    let totalMoney = 0
    for (let i = 0; i < this.shifts!.length; i++) {
      if (this.shifts![i].shiftType === shiftType) {
        const shift = this.shifts![i]
        const wageCalc = new WageCalculator(shift)
        totalHours += shift.hoursWorked
        totalMoney += wageCalc.totalMoney()
      }
    }
    if (totalHours === 0) return 0
    return totalMoney / totalHours
  }

  // Calls helper method for Server ShiftType
  totalHourlyRateServing() {
    return this.totalHourlyRateBasedOnShiftType('Server')
  }

  // Calls helper method for Bartender ShiftType
  totalHourlyRateBartending() {
    return this.totalHourlyRateBasedOnShiftType('Bartender')
  }
}
