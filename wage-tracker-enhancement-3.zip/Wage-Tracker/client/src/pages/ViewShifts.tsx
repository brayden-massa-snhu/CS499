import axios from 'axios'
import { useState, useEffect } from 'react'
import { Shift } from '../types/ShiftType'
import ShiftView from '../components/ShiftView'
import BackArrow from '../components/BackArrow'
import '../styles/ViewShifts.css'

/**
 * Page to display shifts and data from shifts
 *
 * @returns JSX for the ViewShifts page
 */
const ViewShifts = () => {
  // Local state
  const [shifts, setShifts] = useState<Shift[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleDeleteShift = (id: string) => {
    setShifts(shifts.filter((shift) => shift._id != id))
  }
  // Called once to load shifts
  useEffect(() => {
    // Function to fetch shifts from the database
    const fetchShifts = async () => {
      try {
        setLoading(true)
        const res = await axios.get('http://localhost:4000/shifts')
        setShifts(res.data)
      } catch (err) {
        setError(`Error fetching shifts: ${err}`)
      } finally {
        setLoading(false)
      }
    }
    fetchShifts()
  }, [])

  // If still loading
  if (loading) return <div>Loading shifts...</div>
  // If there is an error in the fetch shifts
  if (error) return <div>{error}</div>

  const reversedShifts = [...shifts].reverse()
  return (
    <div id='view-shifts-container'>
      <BackArrow id='view-back-arrow' />
      {shifts.length === 0 && <h1 id='no-shifts'>There are no shifts.</h1>}
      {shifts.length > 0 && (
        <>
          <h1 className='heading' id='view-shifts-heading'>
            Shifts
          </h1>
          <ul id='view-shifts-list'>
            {reversedShifts.map((shift: Shift) => (
              <ShiftView shift={shift} onDelete={handleDeleteShift} />
            ))}
          </ul>
        </>
      )}
    </div>
  )
}
export default ViewShifts
