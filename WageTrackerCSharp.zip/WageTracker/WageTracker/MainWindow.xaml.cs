﻿using System.Windows;
using System.Windows.Navigation;
using WageTracker.Views;

namespace WageTracker
{
    public partial class MainWindow : NavigationWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            // Navigate to the home page on startup
            this.Navigate(new HomePage());
        }
    }
}