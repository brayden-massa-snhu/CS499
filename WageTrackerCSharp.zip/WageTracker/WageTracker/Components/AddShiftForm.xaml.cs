﻿using System.Windows;
using System.Windows.Controls;
using WageTracker.Models;
using WageTracker.Services;

namespace WageTracker.Components
{
    public partial class AddShiftForm : UserControl
    {
        public AddShiftForm()
        {
            InitializeComponent();
        }

        // Checks if all inputs are valid, positive numbers
        private bool IsValidFormInputs(string hours, string cardTips, string cashTips, ShiftType shiftType)
        {
            // Validate Hours
            if (!double.TryParse(hours, out double hoursWorked) || hoursWorked < 0)
            {
                ShowAlert("Please enter a valid positive number for hours worked.");
                return false;
            }

            // Validate Card Tips
            if (!double.TryParse(cardTips, out double cardTipsAmount) || cardTipsAmount < 0)
            {
                ShowAlert("Please enter a valid positive number for card tips.");
                return false;
            }

            // Validate Cash Tips
            if (!double.TryParse(cashTips, out double cashTipsAmount) || cashTipsAmount < 0)
            {
                ShowAlert("Please enter a valid positive number for cash tips.");
                return false;
            }

            // If all inputs are valid
            return true;
        }

        // Handles the submit action
        private void SubmitAddShift(object sender, RoutedEventArgs e)
        {
            string hours = HoursTextBox.Text;
            string cardTips = CardTipsTextBox.Text;
            string cashTips = CashTipsTextBox.Text;
            ShiftType shiftType = ServerRadioButton.IsChecked == true ? ShiftType.Server : ShiftType.Bartender;
            // Makes sure all inputs are valid
            if (IsValidFormInputs(hours, cardTips, cashTips, shiftType))
            {
                // Creates new shift and adds it to the ShiftService, alerts user, and clears input fields
                Shift newShift = new Shift(double.Parse(hours), double.Parse(cashTips), double.Parse(cardTips), shiftType);
                ShiftService.Instance.AddShift(newShift);
                ShowAlert("Shift added successfully");
                HoursTextBox.Clear();
                CardTipsTextBox.Clear();
                CashTipsTextBox.Clear();
            }
        }

        // Method to show custom alert box that aligns with application's styling
        private void ShowAlert(string message)
        {
            var alert = new Alert(message);
            alert.Owner = Window.GetWindow(this);
            alert.ShowDialog();
        }
    }
}
