﻿using System.Windows;

namespace WageTracker.Components
{
    /// <summary>
    /// Interaction logic for Alert.xaml
    /// </summary>
    public partial class Alert : Window
    {
        public Alert(string message)
        {
            InitializeComponent();
            MessageTextBlock.Text = message;
        }

        // Closes the alert window when 'Ok' button is clicked
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
