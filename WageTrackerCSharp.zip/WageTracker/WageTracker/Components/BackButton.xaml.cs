﻿using System.Windows;
using System.Windows.Controls;

namespace WageTracker.Components
{
    
    public partial class BackButton : UserControl
    {
        // Defines EventHandler BackButtonClicked
        public event EventHandler? BackButtonClicked;

        public BackButton()
        {
            InitializeComponent();
        }

        // If BackButton is clicked, invoke method defined in the class the BackButton is rendered in
        private void GoBack_Click(object sender, RoutedEventArgs e)
        {
            BackButtonClicked?.Invoke(this, EventArgs.Empty);
        }
    }
}
