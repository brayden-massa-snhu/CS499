﻿using System.Windows.Controls;

namespace WageTracker.Views
{
    /// <summary>
    /// Interaction logic for AddShiftPage.xaml
    /// </summary>
    public partial class AddShiftPage : Page
    {
        public AddShiftPage()
        {
            InitializeComponent();
            // Subscribe to the BackButton's event
            BackButtonControl.BackButtonClicked += BackButton_BackButtonClicked;
        }

        // Handles the BackButton click event
        private void BackButton_BackButtonClicked(object? sender, EventArgs? e)
        {
            // Perform navigation
            NavigationService?.GoBack();
        }
    }
}
