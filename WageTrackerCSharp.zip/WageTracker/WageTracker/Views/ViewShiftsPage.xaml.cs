﻿using System.Windows.Controls;
using WageTracker.Services;

namespace WageTracker.Views
{
    public partial class ViewShiftsPage : Page
    {
        public ViewShiftsPage()
        {
            InitializeComponent();
            // Loads shift data to the ShiftsListView
            LoadShifts();
            // Subscribe to the BackButton's event
            BackButtonControl.BackButtonClicked += BackButton_BackButtonClicked;
        }
        private void BackButton_BackButtonClicked(object? sender, EventArgs? e)
        {
            // Perform navigation
            NavigationService?.GoBack();
        }

        // Gathers ShiftData from the ShiftService and binds it to the ShiftsListView
        private void LoadShifts()
        {
            var sortedShifts = ShiftService.Instance.Shifts
                .OrderByDescending(shift => shift.Date)
                .ToList();

            ShiftsListView.ItemsSource = sortedShifts;
        }
    }
}
