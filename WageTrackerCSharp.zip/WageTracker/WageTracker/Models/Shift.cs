﻿namespace WageTracker.Models
{
    // Enum for ShiftType
    public enum ShiftType
    {
        Server, Bartender
    }
    public class Shift
    {
        // Fields for shift data
        public static readonly double HOURLY_WAGE = 6.75;
        public DateTime Date { get; } = DateTime.Now;
        public ShiftType ShiftType { get; }
        public double HoursWorked { get; }
        public double CashTips { get; }
        public double CardTips { get; }
        public double TotalMoneyMade { get; }
        public double TotalDollarsPerHour { get; }

        // Constructor to create Shift model based on inputs
        public Shift(double hoursWorked, double cashTips, double cardTips, ShiftType shiftType)
        {
            ShiftType = shiftType;
            HoursWorked = hoursWorked;
            CashTips = cashTips;
            CardTips = cardTips;
            TotalMoneyMade = CalculateTotalMoneyMade();
            TotalDollarsPerHour = CalculateTotalDollarsPerHour();
        }

        // Calculates total money made in the shift, including hourly wage and tips
        private double CalculateTotalMoneyMade()
        {
            return CashTips + CardTips + (HOURLY_WAGE * HoursWorked);
        }

        // Calculates average hourly rate including base hourly wage and tips
        private double CalculateTotalDollarsPerHour()
        {
            if (HoursWorked == 0)
            {
                return 0;
            }
            return TotalMoneyMade / HoursWorked;
        }

    }

}
