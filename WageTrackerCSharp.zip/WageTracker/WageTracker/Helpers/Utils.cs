﻿using System.Windows.Navigation;

namespace WageTracker.Helpers
{
    public static class Utils
    {
        // Click event used for BackButton
        public static void GoBack(NavigationService navigationService)
        {
            if (navigationService != null && navigationService.CanGoBack)
            {
                navigationService.GoBack();
            }
        }
    }
}
