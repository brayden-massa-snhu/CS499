﻿using System.Collections.ObjectModel;
using WageTracker.Models;

namespace WageTracker.Services
{
    // ShiftService used to store global collection of Shifts
    public class ShiftService
    {
        // Defines instance to be accessed accross the application
        private static readonly Lazy<ShiftService> _instance = new Lazy<ShiftService>(() => new ShiftService());

        public static ShiftService Instance => _instance.Value;
        public ObservableCollection<Shift> Shifts { get; private set; }

        private ShiftService()
        {
            Shifts = new ObservableCollection<Shift>();
        }

        // Adds a shift to the ShiftService
        public void AddShift(Shift shift)
        {
            Shifts.Add(shift);
        }

        // Removes a shift from the ShiftService
        public void RemoveShift(Shift shift)
        {
            Shifts.Remove(shift);
        }
    }
}
