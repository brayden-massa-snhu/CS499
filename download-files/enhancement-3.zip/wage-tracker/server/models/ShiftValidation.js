const { z } = require('zod')
/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

/**
 * Adds input validation to creating a new Shift in the database
 */
const shiftSchema = z.object({
  shiftType: z.enum(['Server', 'Bartender'], {
    required_error: 'Shift type is required',
    invalid_type_error: 'Shift type must be one of: Server, Bartender',
  }),
  hoursWorked: z
    .number()
    .min(0, { message: 'Hours worked must be a positive number' }),
  totalCardTips: z
    .number()
    .min(0, { message: 'Total card tips must be a positive number' }),
  totalCashTips: z
    .number()
    .min(0, { message: 'Total cash tips must be a positive number' }),
})

module.exports = shiftSchema
