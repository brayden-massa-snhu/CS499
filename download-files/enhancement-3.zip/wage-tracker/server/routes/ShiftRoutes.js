const router = require('express').Router()
const Shift = require('../models/ShiftModel')
const shiftSchema = require('../models/ShiftValidation')
/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

/**
 * Routes for the Shifts table
 *
 * REST API with full CRUD functionality
 */

// Post route to create new Shift
router.post('/', async (req, res) => {
  try {
    const result = shiftSchema.safeParse(req.body)
    if (!result.success) {
      return res.status(400).json({ errors: result.error.errors })
    }
    const newShift = new Shift(result.data)
    await newShift.save()
    res.status(201).json(newShift)
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Internal server error' })
  }
})

// Get route to get all Shifts
router.get('/', async (req, res) => {
  try {
    const shifts = await Shift.find()
    res.status(200).json(shifts)
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Internal server error' })
  }
})

// Get route with ID to get Shift with specified ID
router.get('/:id', async (req, res) => {
  try {
    const shiftID = req.params.id
    const shift = await Shift.findById(shiftID)
    if (!shift) {
      return res.status(404).json({ message: 'Shift not found' })
    }
    res.status(200).json(shift)
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Internal server error' })
  }
})

// Put route with ID to update Shift with specified ID with new data
router.put('/:id', async (req, res) => {
  try {
    const result = shiftSchema.safeParse(req.body)
    if (!result.success) {
      return res.status(400).json({ errors: result.error.errors })
    }
    const shiftID = req.params.id
    const updatedShift = await Shift.findByIdAndUpdate(shiftID, result.data, {
      new: true,
      runValidators: true,
    })
    if (!updatedShift) {
      return res.status(404).json({ message: 'Shift not found' })
    }
    res.status(200).json(updatedShift)
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Internal server error' })
  }
})

// Delete route with ID to delete Shift with specified ID
router.delete('/:id', async (req, res) => {
  try {
    const shiftID = req.params.id
    const deletedShift = await Shift.findByIdAndDelete(shiftID)
    if (!deletedShift) {
      return res.status(404).json({ message: 'Shift not found' })
    }
    res.status(200).json({})
  } catch (err) {
    console.error(err)
    res.status(500).json({ message: 'Internal server error' })
  }
})

module.exports = router
