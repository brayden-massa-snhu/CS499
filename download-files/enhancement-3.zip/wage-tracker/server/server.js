const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
require('dotenv').config()
const shiftRoutes = require('./routes/ShiftRoutes')
/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

// Initialize the server
const app = express()

// Enables CORS and tells express to use JSON
app.use(express.json())
app.use(cors())

// Connects server to ShiftRoutes
app.use('/shifts', shiftRoutes)

// Connect to DB
mongoose.connect(process.env.DB_URI).then(() => console.log('DB connected'))

// Finds PORT variable in the .env file, or uses default of port 4000
const PORT = process.env.PORT || 4000

// Starts the server
app.listen(process.env.PORT || 4000, () =>
  console.log(`Server running on port ${PORT}`)
)
