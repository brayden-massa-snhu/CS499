import { Shift } from '../types/ShiftType'
import WageCalculator from '../WageCalculator'
import axios from 'axios'
/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

type Props = {
  shift: Shift
  onDelete: (id: string) => void
}
/**
 * Component to display a shift on the ViewShifts page.
 * Each shift will have its own ShiftView
 *
 * @param shift Shift to be displayed
 * @param onDelete Called when a shift is to be deleted
 * @returns
 */
const ShiftView = ({ shift, onDelete }: Props) => {
  //Initialize Wage Calculator
  const calc = new WageCalculator(shift)
  //Attempts to delete shift from axios when called
  const handleDelete = async (id: string) => {
    try {
      await axios.delete(`http://localhost:4000/shifts/${id}`)
      onDelete(id)
    } catch (err) {
      console.error('Failed to delete the shift: ', err)
    }
  }
  return (
    <li key={shift._id} id='shift-view'>
      {shift.shiftType} shift for {shift.hoursWorked.toFixed(1)} hours | Card
      tips: ${shift.totalCardTips} | Cash tips: ${shift.totalCashTips} | $/hr: $
      {calc.totalMoneyPerHour().toFixed(2)} | total $: $
      {calc.totalMoney().toFixed(2)}{' '}
      <button
        className='shift-view-delete'
        onClick={() => handleDelete(shift._id)}
      >
        Delete
      </button>
    </li>
  )
}

export default ShiftView
