import { Link } from 'react-router-dom'
import '../styles/BackArrow.css'
/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

type Props = {
  id: string
}

/**
 * Component to display the back arrow, and give unique styles depending
 * on which page it is being rendered on
 *
 * @param id ID of the image for styling purposes
 * @returns
 */
const BackArrow = ({ id }: Props) => {
  return (
    <Link className='back-arrow' to='/' id={id}>
      <img
        width='50px'
        height='50px'
        className='back-arrow-img'
        id={id + '-img'}
        src='../../public/assets/back-arrow.png'
        alt='back-arrow'
      />
    </Link>
  )
}

export default BackArrow
