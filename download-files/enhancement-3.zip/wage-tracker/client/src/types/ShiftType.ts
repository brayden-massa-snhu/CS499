export type Shift = {
  _id: string
  shiftType: string
  hoursWorked: number
  totalCardTips: number
  totalCashTips: number
  date: Date
}
