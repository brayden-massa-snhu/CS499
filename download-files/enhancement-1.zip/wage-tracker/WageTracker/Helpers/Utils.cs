﻿using System.Windows.Navigation;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker.Helpers
{
    public static class Utils
    {
        // Click event used for BackButton
        public static void GoBack(NavigationService navigationService)
        {
            if (navigationService != null && navigationService.CanGoBack)
            {
                navigationService.GoBack();
            }
        }
    }
}
