﻿using WageTracker.Models;
using WageTracker.Services;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker.Helpers
{
    // Statistics calculator used to calculate statistics based on all Shifts
    public static class StatisticsCalculator
    {
        // Helper to check if shifts exist
        private static bool CheckForShifts()
        {
            return ShiftService.Instance.Shifts.Count != 0;
        }

        // Generic helper method to calculate totals for both hours and money
        private static (double totalHours, double totalMoney) CalculateTotals(Func<Shift, bool> filter)
        {
            double totalHours = 0;
            double totalMoney = 0;

            foreach (Shift shift in ShiftService.Instance.Shifts)
            {
                if (filter(shift))
                {
                    totalHours += shift.HoursWorked;
                    totalMoney += shift.TotalMoneyMade;
                }
            }

            return (totalHours, totalMoney);
        }

        // Helper method to calculate hourly rate based on a filter
        private static double CalculateHourlyRate(Func<Shift, bool> filter)
        {
            if (!CheckForShifts())
            {
                return 0;
            }

            var (totalHours, totalMoney) = CalculateTotals(filter);

            return totalHours == 0 ? 0 : totalMoney / totalHours;
        }

        // Public methods

        // Calculates average hourly rate for all shifts
        public static double TotalHourlyRate()
        {
            return CalculateHourlyRate(shift => true); // No filter, include all shifts
        }

        // Calculates total money for all shifts
        public static double TotalMoney()
        {
            if (!CheckForShifts())
            {
                return 0;
            }

            var (_, totalMoney) = CalculateTotals(shift => true);
            return totalMoney;
        }

        // Calculates total hours for all shifts
        public static double TotalHours()
        {
            if (!CheckForShifts())
            {
                return 0;
            }

            var (totalHours, _) = CalculateTotals(shift => true);
            return totalHours;
        }

        // Returns average hourly rate for serving shifts
        public static double TotalHourlyRateServing()
        {
            return CalculateHourlyRate(shift => shift.ShiftType == ShiftType.Server);
        }

        // Returns average hourly rate for bartending shifts
        public static double TotalHourlyRateBartending()
        {
            return CalculateHourlyRate(shift => shift.ShiftType == ShiftType.Bartender);
        }
    }
}
