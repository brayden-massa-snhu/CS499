﻿using System.Windows.Navigation;
using WageTracker.Views;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker
{
    // Main Window used to navigate user to home screen on app start
    public partial class MainWindow : NavigationWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            // Navigate to the home page on startup
            this.Navigate(new HomePage());
        }
    }
}