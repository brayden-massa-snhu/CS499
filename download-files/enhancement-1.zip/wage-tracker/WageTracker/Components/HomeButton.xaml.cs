﻿using System.Windows;
using System.Windows.Controls;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker.Components
{
    // Buttons on the home screen
    public partial class HomeButton : UserControl
    {
        public HomeButton()
        {
            InitializeComponent();
            // Adds OnClick event to the HomeButtonElement
            HomeButtonElement.Click += (s, e) => OnClick(e);
        }
        public event RoutedEventHandler? Click;

        // Called when the button is clicked, funcionality is defined within the class it is used in
        protected virtual void OnClick(RoutedEventArgs e)
        {
            if (Click != null)
            {
                Click(this, e);
            }
        }

        // Define the ButtonContent as a DependencyProperty
        public static readonly DependencyProperty ButtonContentProperty =
            DependencyProperty.Register("ButtonContent", typeof(string), typeof(HomeButton), new PropertyMetadata(string.Empty));

        // Content for the button, useful to have same style with different text on each button
        public string ButtonContent
        {
            get { return (string)GetValue(ButtonContentProperty); }
            set { SetValue(ButtonContentProperty, value); }
        }
    }
}
