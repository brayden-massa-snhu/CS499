﻿using System.Windows;
using System.Windows.Controls;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker.Components
{
    // Back button for navigation through screens
    public partial class BackButton : UserControl
    {
        // Defines EventHandler BackButtonClicked
        public event EventHandler? BackButtonClicked;

        public BackButton()
        {
            InitializeComponent();
        }

        // If BackButton is clicked, invoke method defined in the class the BackButton is rendered in
        private void GoBack_Click(object sender, RoutedEventArgs e)
        {
            BackButtonClicked?.Invoke(this, EventArgs.Empty);
        }
    }
}
