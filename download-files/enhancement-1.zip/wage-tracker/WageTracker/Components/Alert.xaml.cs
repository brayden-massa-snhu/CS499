﻿using System.Windows;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker.Components
{
    // Custom Alert object
    public partial class Alert : Window
    {
        public Alert(string message)
        {
            InitializeComponent();
            MessageTextBlock.Text = message;
        }

        // Closes the alert window when 'Ok' button is clicked
        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
