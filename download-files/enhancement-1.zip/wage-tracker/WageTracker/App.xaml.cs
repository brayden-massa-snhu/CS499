﻿using System.Windows;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker
{
    // Entry point for application
    public partial class App : Application
    {
    }

}
