﻿using System.Windows;
using System.Windows.Controls;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker.Views
{
    // Home page that displays links to all three other pages
    public partial class HomePage : Page
    {
        public HomePage()
        {
            InitializeComponent();
        }

        // Click handler to navigate to AddShift page
        private void NavigateToAddShift(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddShiftPage());
        }

        // Click handler to navigate to ViewShifts page
        private void NavigateToViewShifts(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ViewShiftsPage());
        }

        // Click handler to navigate to Statistics page
        private void NavigateToStatistics(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new StatisticsPage());
        }
    }

}
