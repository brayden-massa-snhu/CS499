﻿using System.Windows.Controls;
using WageTracker.Services;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker.Views
{
    // View Shifts page, where user can view list of shifts and data about each shift
    public partial class ViewShiftsPage : Page
    {
        public ViewShiftsPage()
        {
            InitializeComponent();
            // Loads shift data to the ShiftsListView
            LoadShifts();
            // Subscribe to the BackButton's event
            BackButtonControl.BackButtonClicked += BackButton_BackButtonClicked;
        }
        private void BackButton_BackButtonClicked(object? sender, EventArgs? e)
        {
            // Perform navigation
            NavigationService?.GoBack();
        }

        // Gathers ShiftData from the ShiftService and binds it to the ShiftsListView
        private void LoadShifts()
        {
            var sortedShifts = ShiftService.Instance.Shifts
                .OrderByDescending(shift => shift.Date)
                .ToList();

            ShiftsListView.ItemsSource = sortedShifts;
        }
    }
}
