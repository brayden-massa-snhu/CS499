﻿using System.Windows.Controls;
using WageTracker.Helpers;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker.Views
{
    // Statistics page that shows statistics about all collective shifts
    public partial class StatisticsPage : Page
    {
        public StatisticsPage()
        {
            InitializeComponent();
            // Loads statistics to the text blocks of the page
            LoadStatistics();

            // Subscribe to the BackButton's event
            BackButtonControl.BackButtonClicked += BackButton_BackButtonClicked;
        }
        private void BackButton_BackButtonClicked(object? sender, EventArgs? e)
        {
            // Perform navigation
            NavigationService?.GoBack();
        }

        // Set the text blocks with values from StatisticsCalculator
        private void LoadStatistics()
        {
            TotalHoursTextBlock.Text = StatisticsCalculator.TotalHours().ToString("N2");
            TotalMoneyTextBlock.Text = StatisticsCalculator.TotalMoney().ToString("C");
            AverageHourlyRateTextBlock.Text = StatisticsCalculator.TotalHourlyRate().ToString("C");
            ServingHourlyRateTextBlock.Text = StatisticsCalculator.TotalHourlyRateServing().ToString("C");
            BartendingHourlyRateTextBlock.Text = StatisticsCalculator.TotalHourlyRateBartending().ToString("C");
        }
    }
}
