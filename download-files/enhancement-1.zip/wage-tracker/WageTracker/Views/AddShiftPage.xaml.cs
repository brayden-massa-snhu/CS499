﻿using System.Windows.Controls;

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
namespace WageTracker.Views
{
    // AddShift page where user can create new Shift
    public partial class AddShiftPage : Page
    {
        public AddShiftPage()
        {
            InitializeComponent();
            // Subscribe to the BackButton's event
            BackButtonControl.BackButtonClicked += BackButton_BackButtonClicked;
        }

        // Handles the BackButton click event
        private void BackButton_BackButtonClicked(object? sender, EventArgs? e)
        {
            // Perform navigation
            NavigationService?.GoBack();
        }
    }
}
