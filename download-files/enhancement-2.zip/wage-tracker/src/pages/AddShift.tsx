import AddShiftInput from '../components/AddShiftInput'
import BackArrow from '../components/BackArrow'
import { ChangeEvent, FormEvent, useState } from 'react'
import SelectShiftType from '../components/SelectShiftType'
import { useNavigate } from 'react-router-dom'
import '../styles/AddShift.css'
import { Shift } from '../types/ShiftType'
import { useShifts } from '../hooks/useShifts'

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

/**
 * Contains the form for user to create a new shift and add to the global state
 *
 * @returns JSX for the AddShift page
 */
const AddShift = () => {
  //Local state for user input fields
  const [hoursWorked, setHours] = useState('')
  const [totalCardTips, setCardTips] = useState('')
  const [totalCashTips, setCashTips] = useState('')
  const [shiftType, setShiftType] = useState('Server')

  //Retrieves the appendShift method from global state
  const { appendShift } = useShifts()

  //Sets up the react-router-dom navigate function, to navigate
  //to ViewShifts after creating one
  const navigate = useNavigate()

  //Helper function to check if input is a valid number
  const isValidNumber = (value: string): boolean => {
    return !isNaN(Number(value)) && value.trim() !== ''
  }
  //Helper to check if the form is valid
  const isFormValid = (): boolean => {
    return (
      isValidNumber(hoursWorked) &&
      isValidNumber(totalCardTips) &&
      isValidNumber(totalCashTips)
    )
  }
  //Called when submit button is clicked, saves new shift data to global state,
  //and navigates to View Shifts page
  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (isFormValid()) {
      const newShift: Shift = {
        shiftType,
        hoursWorked: Number(hoursWorked),
        totalCardTips: Number(totalCardTips),
        totalCashTips: Number(totalCashTips),
        id: 0,
        date: new Date(),
      }
      appendShift(newShift)
      navigate('/view')
    }
  }
  return (
    <div className='container'>
      <h1 className='heading'>Add Shift</h1>
      <main className='main'>
        <BackArrow id='add-back-arrow' />

        <form onSubmit={handleSubmit} id='add-shift-form'>
          <AddShiftInput
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setHours(e.target.value)
            }
            fieldName='hoursWorked'
          />
          <AddShiftInput
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setCardTips(e.target.value)
            }
            fieldName='totalCardTips'
          />
          <AddShiftInput
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setCashTips(e.target.value)
            }
            fieldName='totalCashTips'
          />
          <SelectShiftType shiftType={shiftType} setShiftType={setShiftType} />
          <input
            type='submit'
            id='add-shift-btn'
            className='btn'
            value='Save'
          />
        </form>
      </main>
    </div>
  )
}
export default AddShift
