import { Link } from 'react-router-dom'
import '../styles/home.css'

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

/**
 * Home page for application, contains links to the other 3 pages
 *
 * @returns JSX for home page
 */
const Home = () => {
  return (
    <div className='container'>
      <h1 className='heading'>Welcome to Wage Tracker!</h1>
      <main className='main'>
        <div id='home-links'>
          <Link className='btn' to='/add'>
            Add New Shift
          </Link>
          <Link className='btn' to='/view'>
            View Shifts
          </Link>
          <Link className='btn' to='/stats'>
            Statistics
          </Link>
        </div>
      </main>
    </div>
  )
}

export default Home
