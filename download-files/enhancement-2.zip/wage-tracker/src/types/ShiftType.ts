/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

export type Shift = {
  shiftType: string
  hoursWorked: number
  totalCardTips: number
  totalCashTips: number
  id: number
  date: Date
}
