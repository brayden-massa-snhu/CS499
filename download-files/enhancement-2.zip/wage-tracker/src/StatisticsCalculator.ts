import { DoublyLinkedList } from './DoublyLinkedList'
import { Shift } from './types/ShiftType'
import WageCalculator from './WageCalculator'

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

/**
 * Calculator to calculate information across all shifts (averages, totals, etc.)
 */
export default class StatisticsCalculator {
  shifts: DoublyLinkedList<Shift>
  constructor(shifts: DoublyLinkedList<Shift>) {
    this.shifts = shifts
  }

  //Ensures shifts list is not empty
  private checkForShifts() {
    return this.shifts && this.shifts.getLength() > 0
  }
  //Returns total average hourly rate (wage and tips) for all shifts
  totalHourlyRate() {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalHours = 0
    let totalMoney = 0
    let currentNode = this.shifts.head
    while (currentNode) {
      const shift = currentNode.data
      const wageCalc = new WageCalculator(shift)
      totalHours += shift.hoursWorked
      totalMoney += wageCalc.totalMoney()
      currentNode = currentNode.next
    }
    if (totalHours === 0) return 0
    return totalMoney / totalHours
  }

  //Returns total sum of money for all shifts (wage and tips)
  totalMoney() {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalMoney = 0
    let currentNode = this.shifts.head
    while (currentNode) {
      const wageCalc = new WageCalculator(currentNode.data)
      totalMoney += wageCalc.totalMoney()
      currentNode = currentNode.next
    }
    return totalMoney
  }

  //Returns total sum of hours across all shifts
  totalHours() {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalHours = 0
    let currentNode = this.shifts.head
    while (currentNode) {
      totalHours += currentNode.data.hoursWorked
      currentNode = currentNode.next
    }
    return totalHours
  }

  //Helper method to calculate average hourly rate (tips and wage) for shifts
  //of selected ShiftType
  private totalHourlyRateBasedOnShiftType(shiftType: string) {
    if (!this.checkForShifts()) {
      return 0
    }
    let totalHours = 0
    let totalMoney = 0
    let currentNode = this.shifts.head
    while (currentNode) {
      const shift = currentNode.data
      if (shift.shiftType === shiftType) {
        const wageCalc = new WageCalculator(shift)
        totalHours += shift.hoursWorked
        totalMoney += wageCalc.totalMoney()
      }
      currentNode = currentNode.next
    }
    if (totalHours === 0) return 0
    return totalMoney / totalHours
  }

  //Calls helper method for Server ShiftType
  totalHourlyRateServing() {
    return this.totalHourlyRateBasedOnShiftType('Server')
  }

  //Calls helper method for Bartender ShiftType
  totalHourlyRateBartending() {
    return this.totalHourlyRateBasedOnShiftType('Bartender')
  }
}
