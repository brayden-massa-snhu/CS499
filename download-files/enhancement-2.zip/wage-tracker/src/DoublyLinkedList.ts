/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

// Node class for DoublyLinkedList
class Node<T> {
  public data: T // Data of type T stored in the node
  public next: Node<T> | null = null
  public prev: Node<T> | null = null

  constructor(data: T) {
    this.data = data
  }
}
// Doubly Linked List class
export class DoublyLinkedList<T> {
  public head: Node<T> | null = null
  public tail: Node<T> | null = null
  private length: number = 0

  /**
   * Append a new node with data of type T
   *
   * @param data Data to append to list
   *
   * Time Complexity: O(1) since node is being added directly to tail
   * Space Complexity: O(1) since only one node is being created
   */
  append(data: T): void {
    const newNode = new Node(data)
    if (!this.head) {
      // If the list is empty, set the new node as both head and tail
      this.head = newNode
      this.tail = newNode
    } else if (this.tail) {
      // Otherwise, append the node at the tail
      this.tail.next = newNode
      newNode.prev = this.tail
      this.tail = newNode
    }
    this.length++
  }

  /**
   * Delete a node by providing a comparison function
   *
   * @param compareFn Comparison function
   * @returns Returns true if successful
   *
   * Time complexity: O(n) because worst case requires traversal through entire list
   * Space complexity: O(1), only need space for the node being deleted
   */
  delete(compareFn: (data: T) => boolean): void {
    let current = this.head
    while (current) {
      if (compareFn(current.data)) {
        if (current.prev) {
          current.prev.next = current.next
        } else {
          this.head = current.next // Deleting the head node
        }
        if (current.next) {
          current.next.prev = current.prev
        } else {
          this.tail = current.prev // Deleting the tail node
        }
        this.length--
        return
      }
      current = current.next
    }
  }

  /**
   * Convert the linked list to an array
   *
   * @returns Returns the list as an Array of type T
   *
   * Time complexity: O(n), because list needs to be traversed through once every time
   * Space complexity: O(n), because a new list is created to store the result
   */
  toArray(): T[] {
    const result: T[] = []
    let current = this.head
    while (current) {
      result.push(current.data)
      current = current.next
    }
    return result
  }

  /**
   * Get the length of the list
   *
   * @returns Returns the length of the list
   *
   * Time complexity: O(1), because it just returns the length property
   * Space complexity: O(1), no extra space is used
   */
  //
  getLength(): number {
    return this.length
  }

  /**
   * Defines a method to sort the linked list using the insertion sort algorithm
   *
   * @param comparator Comparator function for the two pieces of data
   *
   * Time complexity: O(n^2), because the outer loop traverses all nodes and the
   * inner loop may traverse nodes already sorted
   * Space complexity: O(n) for the creation of the sorted list
   */
  insertionSort(comparator: (a: T, b: T) => number) {
    if (!this.head || !this.head.next) return

    let sorted: DoublyLinkedList<T> = new DoublyLinkedList<T>()
    let currentNode: Node<T> | null = this.head
    //Traverse the list and insert each node in order
    while (currentNode) {
      let nextNode: Node<T> | null = currentNode.next
      this.insertInOrder(sorted, currentNode, comparator)
      currentNode = nextNode
    }
    this.head = sorted.head
    this.tail = sorted.tail
    this.length = sorted.length
  }
  /**
   * Helper function to insert a node into the sorted list in the correct order
   *
   * @param sortedList List being sorted
   * @param newNode Node to be inserted
   * @param comparator Comparator function
   *
   * Time complexity: O(n) for each insertion due to traversal of the sorted list
   * Space complexity: O(1) for each insertion, nothing is being created in this function
   */
  insertInOrder(
    sortedList: DoublyLinkedList<T>,
    newNode: Node<T>,
    comparator: (a: T, b: T) => number
  ) {
    if (
      !sortedList.head ||
      comparator(newNode.data, sortedList.head.data) < 0
    ) {
      // If sorted list is empty or the new node is smaller than the head, insert at beginning
      newNode.next = sortedList.head
      if (sortedList.head) {
        sortedList.head.prev = newNode
      }
      sortedList.head = newNode
      sortedList.tail = sortedList.tail || newNode
    } else {
      let current = sortedList.head
      // Traverse the sorted list to find the right position
      while (current.next && comparator(newNode.data, current.next.data) > 0) {
        current = current.next
      }
      newNode.next = current.next
      if (current.next) {
        current.next.prev = newNode
      }
      current.next = newNode
      newNode.prev = current
      sortedList.tail = newNode
    }
    sortedList.length++
  }
}
