import { useContext } from 'react'
import { ShiftContext } from '../context/ShiftContext'

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */

//Custom hook to make using global state more simple
export const useShifts = () => {
  const context = useContext(ShiftContext)
  if (!context) {
    throw new Error('useShifts must be used within a ShiftProvider')
  }
  return context
}
