import { ChangeEvent } from 'react'

/**
 * Author: Brayden Massa
 * Created: 10.18.2024
 * Version: 1.0
 */
type Props = {
  shiftType: string
  setShiftType: (value: string) => void
}

/**
 * Radio buttons to select the shift type when creating a new shift
 *
 * @param shiftType Either 'Server' or 'Bartender'
 * @param setShiftType Function to set the ShiftType of the parent
 * @returns
 */
const SelectShiftType = ({ shiftType, setShiftType }: Props) => {
  //Called when a new ShiftType is selected
  const handleRadioChange = (e: ChangeEvent<HTMLInputElement>) => {
    setShiftType(e.target.value)
  }
  return (
    <div id='select-shift-type'>
      <div className='select-shift-radio'>
        <label htmlFor='server-radio'>Server</label>
        <input
          className='select-shift-radio-input'
          type='radio'
          id='server-radio'
          name='shift-type-radio'
          value='Server'
          onChange={handleRadioChange}
          checked={shiftType === 'Server'}
        />
      </div>
      <div className='select-shift-radio'>
        <label htmlFor='bartender-radio'>Bartender</label>
        <input
          className='select-shift-radio-input'
          type='radio'
          id='bartender-radio'
          name='shift-type-radio'
          value='Bartender'
          onChange={handleRadioChange}
          checked={shiftType === 'Bartender'}
        />
      </div>
    </div>
  )
}

export default SelectShiftType
