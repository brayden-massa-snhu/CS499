import AddShiftInput from '../components/AddShiftInput'
import BackArrow from '../components/BackArrow'
import { ChangeEvent, FormEvent, useState } from 'react'
import SelectShiftType from '../components/SelectShiftType'
import { useNavigate } from 'react-router-dom'
import '../styles/AddShift.css'
import { Shift } from '../types/ShiftType'
import { useShifts } from '../hooks/useShifts'

const AddShift = () => {
  const [hoursWorked, setHours] = useState('')
  const [totalCardTips, setCardTips] = useState('')
  const [totalCashTips, setCashTips] = useState('')
  const [shiftType, setShiftType] = useState('Server')

  const { shifts, setShifts } = useShifts()

  const navigate = useNavigate()

  const isValidNumber = (value: string): boolean => {
    return !isNaN(Number(value)) && value.trim() !== ''
  }

  const isFormValid = (): boolean => {
    return (
      isValidNumber(hoursWorked) &&
      isValidNumber(totalCardTips) &&
      isValidNumber(totalCashTips)
    )
  }
  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (isFormValid()) {
      const newId = shifts.length > 0 ? shifts[shifts.length - 1].id + 1 : 1
      const shift: Shift = {
        shiftType,
        hoursWorked: Number(hoursWorked),
        totalCardTips: Number(totalCardTips),
        totalCashTips: Number(totalCashTips),
        id: newId,
      }
      setShifts((prevShifts) => {
        const updatedShifts = [...prevShifts, shift]
        return updatedShifts
      })
      navigate('/view')
    }
  }
  return (
    <div className='container'>
      <h1 className='heading'>Add Shift</h1>
      <main className='main'>
        <BackArrow id='add-back-arrow' />

        <form onSubmit={handleSubmit} id='add-shift-form'>
          <AddShiftInput
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setHours(e.target.value)
            }
            fieldName='hoursWorked'
          />
          <AddShiftInput
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setCardTips(e.target.value)
            }
            fieldName='totalCardTips'
          />
          <AddShiftInput
            onChange={(e: ChangeEvent<HTMLInputElement>) =>
              setCashTips(e.target.value)
            }
            fieldName='totalCashTips'
          />
          <SelectShiftType shiftType={shiftType} setShiftType={setShiftType} />
          <input
            type='submit'
            id='add-shift-btn'
            className='btn'
            value='Save'
          />
        </form>
      </main>
    </div>
  )
}
export default AddShift
